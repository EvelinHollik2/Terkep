package com.example.terkep;

import androidx.fragment.app.FragmentActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.terkep.databinding.ActivityMarketBinding;

public class MarketActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMarketBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMarketBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        btnNavigate.setOnClickListener{
            startNavigation();
        }
        btnPublich.setOnClickListEvent(){
            publichEvent();
        }
    }

    private void publichEvent() {
        val intentSend = Intent(Intent.ACTION_SEND);
        intentSend.type = "text/plain";
        intentSend.putExtra(Intent.EXTRA_TEXT, value:"https://www.facebook.com/bolhapiacom/")
        intentSend.setPackage("com.facebook.katana");
        try{
            startActivity(intentSend);
        }catch (e:ActivityNotFoundException){
            e.prontStackTrace
        }
    }

    private void startNavigation() {
        val lat = newMarker?.position.latitude;
        val lng = newMarker?.position.longitude;
        val wazeUri = "waze://?q=${etDetails.text}&navigate=yes";
        val intentTest = Intent(Intent.ACTION_VIEW);
            intentTest.data= Uri.parse(waseUri);
            startActivity(IntentTest);
    }

    var newMarker: Marker? = null;
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.viSettings.isZoomGesturesEnabled = true;
        mMap.viSettings.isZoomControlsEnabled = true;
        mMap.setOnMapClickListener {
            if (newMarker == null) {
                mMap.clear();
                newMarker = mMap.addMarker(
                        MarkerOptions().position(it).title("My market").snippet("Gyertek 10 és 15 között");
                )
                newMarker ?.isDraggale = true
            } else {
                newMarker ?.position = it
            }
            updateAddress();
            mMap.animateCamera(CameraUpdateFactory.newLating(it));
        }
    }
}