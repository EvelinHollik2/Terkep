package com.example.terkep;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityOptionsCompat;

import android.app.ActivityOptions;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLogin.setOnCLickListener { it: View
            var intentMarket = Intent(package.this, Market::class.java)
            val p1 = andorid.core.util.Pair.create<View, String>(ivLogo, b:"logo")
            val option = ActivityOptionsCompat.makeSceneTransitionAnimation(
                    activity:this, p1
            )
            startActivity(intentMarket)
        }
    }
}